// key.h
// ����ģ��ͷ�ļ�
// By seesea

#ifndef _KEY_H_
#define _KEY_H_

#include <arduino.h>

#define KEY_UP    15
#define KEY_DOWN  14
#define KEY_LEFT  13
#define KEY_RIGHT 12
#define KEY_TEST  11
#define KEY_RESET 10

void keyInit();
int  keyRead();

#endif
